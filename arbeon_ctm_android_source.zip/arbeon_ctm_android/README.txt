ARBEON CTM — projet Android

Le dossier contient un projet Android Studio qui embarque l'application HTML dans une WebView, hors ligne.
Pour générer l'APK : ouvrir ce dossier dans Android Studio, laisser Gradle synchroniser, puis choisir Build > Build APK(s).
L'APK de débogage se trouvera normalement dans app/build/outputs/apk/debug/app-debug.apk.

Les données de l'application sont conservées dans le stockage local WebView de l'application. Exporter régulièrement une sauvegarde depuis l'onglet Clients.
